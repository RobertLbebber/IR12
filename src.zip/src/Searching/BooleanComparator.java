/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Searching;

import Analyzing.Document;
import Analyzing.DocumentList;
import Driver.SearchDriver;
import Indexing.NegativeTerm;
import Indexing.PostingIndex;
import Indexing.Postings;
import Indexing.PostingsList;
import Indexing.TermPair;
import Indexing.Terms;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;

/**
 *
 * @author rl07bebb
 */
public class BooleanComparator {

   Postings postings;
   Postings postings2;
   BooleanComparator compare;
   BooleanComparator compare2;
   DocumentList docList;
   PostingsList postList;
   Map<Terms[], String> termMap = new HashMap<>();
   int termType;

   public BooleanComparator(int termType) {
      this.termType = termType;
   }

   public BooleanComparator(Postings t) {
      postings = t;
      this.termType = 0;
   }

   public BooleanComparator(Postings t, int type) {
      postings = t;
      this.termType = type;
   }

   public BooleanComparator(BooleanComparator p, int type) {
      compare = p;
      termType = type;
   }

   public void getPostings() {
      if (compare != null && postings2 == null) {
         if (termType == 2) {
            notTransformation();
         }
         compare.getPostings();
         termMap = compare.termMap;
      } else if (compare != null && postings2 != null) {
         compare.getPostings();
         termMap = compare.termMap;
         if (termType == 2) {
            notTransformation(postings2, compare);
            return;
         } else if (termType == 1) {

         }
      } else if (postings != null && compare2 != null) {
         notTransformation(postings, compare2);
      } else if (postings != null && postings2 == null) {
         for (Terms t : postings.terms) {
            termMap.put(new Terms[]{t}, t.getDocID());
         }
         if (termType == 2) {
            notTransformation();
         }
      } else if (postings != null && postings2 != null && termType == 1) {
         for (Terms t : postings.terms) {
            for (Terms t2 : postings2.terms) {
               if (t.getDocID().equals(t2.getDocID())) {
                  termMap.put(new Terms[]{t, t2}, t.getDocID());
               }
            }
         }
      }
   }

   private HashSet<Document> termlessDocs;

   private void notTransformation() {
      termlessDocs = null;
      Iterator it = termMap.keySet().iterator();
      while (it.hasNext()) {
         Terms[] term = (Terms[]) it.next();
         for (Terms t : term) {
            termlessDocs = termlessDocuments(t, termlessDocs);
         }
      }
      termMap.clear();
      Iterator it2 = termlessDocs.iterator();
      while (it2.hasNext()) {
         Document doc = (Document) it2.next();
         String docId = doc.getDocID();
         int docIndex = SearchDriver.fullDictionary.getDocValue(docId);
         termMap.put(new Terms[]{new NegativeTerm(docIndex, docId)}, docId);
      }
   }

   private HashSet<Document> termlessDocuments(Terms t, HashSet<Document> termlessDocs) {
      HashSet<Document> list = new HashSet<>(10000);
      HashMap<String, PostingIndex> mapping = SearchDriver.fullDictionary.getHash();
      PostingIndex postIn = mapping.get(t.getTerm());
      int termIndex = postIn.getIndex();
      Iterator it;
      if (termlessDocs == null) {
         it = SearchDriver.docList.getAll().iterator();
      } else {
         it = termlessDocs.iterator();
      }
      while (it.hasNext()) {
         Document doc = (Document) it.next();
         if (!doc.contains(termIndex)) {
            list.add(doc);
         }
      }
      return list;
   }

   private void notTransformation(Postings post, BooleanComparator compare) {

      int size = post.size();
      for (int i = 0; i < size; i++) {
         this.termMap.put(new Terms[]{post.get(i)}, post.getName());
      }
      compare.termType = 0;
      compare.generatePostings();

      Iterator it = compare.termMap.keySet().iterator();
      while (it.hasNext()) {
         Terms[] t = (Terms[]) it.next();
         String termName = t[0].getDocID();
         Iterator it2 = termMap.keySet().iterator();
         while (it2.hasNext()) {
            /*
            
            
                     Concurremcy Error
            
            
            
            */
            Terms[] term = (Terms[]) it2.next();
            if (term[0].getDocID().equals(termName)) {
               this.termMap.remove(term);
            }
         }
      }

   }

   public Postings generatePostings() {
      Postings list = new Postings();
      getPostings();
      Iterator it = termMap.keySet().iterator();
      while (it.hasNext()) {
         Terms[] t = (Terms[]) it.next();
         if (t.length == 2) {
            list.add(new TermPair(t[0], t[1]));
         } else {
            list.add(t[0]);
         }
      }
      return list;
   }

   public void addTerm(Postings t, int type) {
      termType = type;
      if (postings == null && compare == null) {
         postings = t;
      } else {
         postings2 = t;
      }
   }

   public void addTerm(BooleanComparator c) {
      if (postings == null) {
         compare = c;
      } else {
         compare2 = c;
      }
   }

   public void setType(int type) {
      this.termType = type;
   }

   public boolean isFull() {
      if (termType == 2) {
         return (compare != null && (postings != null || compare.isFull()));
      } else if (compare != null && compare.isFull() && postings != null) {
         return true;
      }
      return (postings != null && postings2 != null);
   }
}
