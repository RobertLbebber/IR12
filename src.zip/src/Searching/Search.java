/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Searching;

import Analyzing.Document;
import Analyzing.DocumentList;
import Analyzing.Tokenizer;
import Driver.SearchDriver;
import Indexing.Dictionary;
import Indexing.PostingIndex;
import Indexing.Postings;
import Indexing.PostingsList;
import Indexing.Terms;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.regex.Pattern;

/**
 * This class operates two searching types. One Search is from the driver and
 * will output a response in the Console. The other search type will read a
 * search file and output the file into the posting file that it receives.
 *
 * @author rl07bebb
 */
public class Search {

   private Pattern pattern = Pattern.compile("[\\W\\d\\s]");
   private Dictionary localdic;
   private Tokenizer token;
   private Document searchDoc;

   public Search(File stopList) {
      localdic = new Dictionary();
      token = new Tokenizer(stopList, SearchDriver.fullPostingsList);
   }

   /**
    * This method is used to search the terms from the search file contained in
    * the dictionary.
    *
    * @param query the user search request.
    * @param full
    * @return
    */
   public String searchFromDictionary(File query) {
      StringBuilder sb = new StringBuilder();
      String results = "";
      searchDoc = new Document("Query");
      token.readFile(searchDoc, localdic, query);
      HashMap<String, PostingIndex> fullHash = SearchDriver.fullDictionary.getHash();
      for (String n : localdic.getHash().keySet()) {
         if (fullHash.containsKey(n)) {
            int index = SearchDriver.fullDictionary.getIndex(n);
            sb.append(SearchDriver.fullPostingsList.getTermName(index).toString());
         }
      }
      results = sb.toString();
      return results;
   }

   public String userInput() {
      Scanner scan = new Scanner(System.in);
      System.out.print("What Search Term Would You Like To Look For? ");
      return scan.nextLine();
   }

   public String searchFromQuery(String query) {
      StringBuilder sb = new StringBuilder();
      String results = "";
      token.readQuery(query, localdic);
      HashMap<String, PostingIndex> fullHash = SearchDriver.fullDictionary.getHash();
      for (String n : localdic.getHash().keySet()) {
         if (fullHash.containsKey(n)) {
            int index = SearchDriver.fullDictionary.getIndex(n);
            sb.append(SearchDriver.fullPostingsList.get(index).toString());
         }
      }
      results = sb.toString();
      return results;
   }

   public String searchFromQueryBoolean(String query) {
      StringBuilder sb = new StringBuilder();
      String results = "";
      token.readQuery(query, localdic);
      booleanParser(query, token);
      results = resultsList.toString();
      return results;
   }

   private PostingsList resultsList;

   private void booleanParser(String query, Tokenizer token) {
      ArrayList<Postings> termList = new ArrayList<>();
      try (Scanner scanner = new Scanner(query)) {
         while (scanner.hasNext()) {
            String term = scanner.next();
            term = term.toLowerCase();
            if (!SearchDriver.fullDictionary.isNewTerm(term)) {
               //This Section addresses unique terms
               int termLoc = SearchDriver.fullDictionary.getIndex(term);
               Postings postings = SearchDriver.fullPostingsList.get(termLoc);
               termList.add(postings);
            } else if (term.equals("and") || term.equals("not")) {
               //This Section addresses AND & NOT terms
               termList.add(new Postings(term, null, -1));
            }
         }
      }
      cleanList(termList);
      resultsList = new PostingsList();
      recurssion(termList, null, 0);
   }

   /**
    * This Method Focuses on preventing Error-Inducing Queries from affecting
    * the Search. This Section is dedicated to making sure that any error in
    * user input will not yield incorrect searches.
    *
    * An example of this would be Term 'A' AND NOT AND NOT Term 'B' resulting in
    * a search of Unmistakable Gibberish. Instead this query will instead search
    * 'A' Union NOT 'B'
    *
    * @param termList
    */
   private void cleanList(ArrayList<Postings> termList) {
      Iterator i = termList.iterator();
      int key = 0;
      while (i.hasNext()) {
         Postings p = (Postings) i.next();
         if (p.getName().equals("and")) {
            //This Section Addresses AND Terms
            key = 1;
            ArrayList<Postings> ignore = new ArrayList<>();
            while (i.hasNext()) {
               Postings post1 = (Postings) i.next();
               String p1 = post1.getName().toLowerCase();
               //This Section Clears out consecutive AND's
               if (key == 1 && p1.equals("and")) {
                  termList.remove(p);
                  termList.remove(post1);
                  cleanList(termList);
                  return;
               }
               //This Section Prevents Continued Series of Alternative AND OR's
               if ((key == 3 || key == 1) && p1.equals("not")) {
                  key = 2;
                  ignore.add(post1);
               } else if (key == 2 && p1.equals("and")) {
                  key = 3;
                  ignore.add(post1);
               } else if (key == 3 && p1.equals("and")) {
                  ignore.add(p);
                  ignore.add(post1);
                  for (Postings ig : ignore) {
                     termList.remove(ig);
                  }
                  cleanList(termList);
                  return;
               } //This Section Prevents AND NOT NOT 
               else if (key == 2 && p1.equals("not")) {
                  ignore.add(p);
                  for (Postings ig : ignore) {
                     termList.remove(ig);
                  }
                  cleanList(termList);
                  return;
               }
               //This Section Ends The Loop When A Unique Term Is Found
               if (!p1.equals("not") || !p1.equals("and")) {
                  break;
               }
            }
            ignore.clear();
         } else if (p.getName().equals("not")) {
            //This Section Addresses The NOT Terms
            if (i.hasNext()) {
               Postings post1 = (Postings) i.next();
               String p1 = post1.getName().toLowerCase();
               //This Section Prevents NOT Followed By A AND
               if (p1.equals("and")) {
                  termList.remove(p);
                  termList.remove(post1);
                  cleanList(termList);
                  return;
               }
               //This Section Prevents NOT Followed By A NOT
               if (p1.equals("not")) {
                  termList.remove(p);
                  cleanList(termList);
                  return;
               }
               //This Section Ends The Loop When A Unique Term Is Found
               if (!p1.equals("not") || !p1.equals("and")) {
                  break;
               }
            }
         }
      }
   }

   /**
    * This Method is responsible for creating a tree of comparable terms. This
    * is done recursively for ever posting of each term.
    *
    * @param termList
    * @param previousTerm
    * @param index
    */
   public void recurssion(ArrayList<Postings> termList,
           BooleanComparator previousTerm, int index) {
      
      if (index >= termList.size()) {
         if(previousTerm==null){
            return;
         }
         Postings post = previousTerm.generatePostings();
         resultsList.add(post);
         return;
      }
      Postings posting = termList.get(index);
      int keyTermValue = isKeyTerm(posting.getName());
      if (previousTerm == null) {
         if (keyTermValue == 2) {
            previousTerm = new BooleanComparator(2);
         } else if (keyTermValue == 0) {
            previousTerm = new BooleanComparator(posting);
         }
         index++;
         recurssion(termList, previousTerm, index);
      } else {
         if (previousTerm.isFull()) {
            previousTerm.getPostings();
            index++;
            if (previousTerm.termType == 1) {
               recurssion(termList, new BooleanComparator(previousTerm, 1), index);
            } else {
               resultsList.add(previousTerm.generatePostings());
               recurssion(termList, new BooleanComparator(posting, 0), index);
            }
         } else if ((previousTerm.termType == 0 && keyTermValue == 0)||
                 (previousTerm.termType == 2&&keyTermValue == 2)) {
            resultsList.add(previousTerm.generatePostings());
            recurssion(termList, null, index);
         } else {
            if (previousTerm.termType == 2) {
               previousTerm.addTerm(termList.get(index), 2);
               index++;
               recurssion(termList, previousTerm, index);
            } else if (previousTerm.termType == 1) {
               if (keyTermValue == 2 && termList.size() > index + 1) {
                  index++;
                  Postings posting1 = termList.get(index);
                  BooleanComparator currentTerm=new BooleanComparator(posting1, 2);
                  //currentTerm.generatePostings()
                  previousTerm.addTerm(currentTerm);
                  currentTerm= new BooleanComparator(previousTerm.generatePostings());
                  index++;
                  recurssion(termList, currentTerm, index);
               } else if (keyTermValue == 0) {
                  previousTerm.addTerm(termList.get(index), 1);
                  resultsList.add(previousTerm.generatePostings());
                  index++;
                  recurssion(termList, null, index);
               }
            } else if (keyTermValue == 1) {
               previousTerm.setType(keyTermValue);
               index++;
               recurssion(termList, previousTerm, index);
            }
         }
      }
   }

   /**
    * This Method is Responsible for determining if the Word is a key term or a
    * unique term. OR key Term is on Default
    *
    * @param term the key term or unique word
    * @return
    */
   private int isKeyTerm(String term) {
      switch (term.toLowerCase()) {
         case "and":
            return 1;
         case "not":
            return 2;
         default:
            if (token.containsInStopList(term)) {
               return -1;
            }
            return 0;
      }
   }

   /**
    * This method rights the search into a resulting file.
    *
    * @param results
    * @param file
    */
   public void toFile(Dictionary results, File file) {
      new PostingsList(file).writeList(results.toString());
   }

   public void toFile(String results, File file) {
      new PostingsList(file).writeList(results);
   }
}
