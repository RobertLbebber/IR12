/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Indexing;

import Analyzing.Document;
import java.io.Serializable;
import java.util.ArrayList;

/**
 * This Class is an intermediate class for the PostingList Its primary purpose
 * is for getting the Arraylist of a given term. The Secondary feature of this
 * class is to expediate the searching process for documents and arraylist size
 * length.
 *
 * @author rl07bebb
 */
public class Postings implements Serializable {

   public ArrayList<Terms> terms = new ArrayList<>();
   private String lastDocumentID;

   public Postings(String s, String d, int l) {
      terms.add(new Terms(s, d, l));
      lastDocumentID = d;
   }

   public Postings() {
   }

   public Postings(Terms t) {
      terms.add(new Terms(t.getTerm(), t.getDocID(), t.getFOccurence()));
   }

   public Postings(Postings p) {
      terms = p.terms;
   }

   public void add(Terms t) {
      terms.add(t);
   }

   public void add(Document t) {
      lastDocumentID = t.getDocID();
   }

   public void remove(Terms t) {
      terms.remove(t);
   }

   public int size() {
      return terms.size();
   }

   public void add(Postings p) {
      for (Terms t : p.terms) {
         terms.add(t);
      }
   }

   public Terms get(int i) {
      return terms.get(i);
   }

   public String getName() {
      return terms.get(0).getTerm();
   }

   public boolean isEmpty() {
      return terms.isEmpty();
   }

   public int last() {
      return terms.size() - 1;
   }

   public boolean isNewDocument(Document d) {
      return lastDocumentID != d.getDocID();
   }

   public void setLastDoc(String doc) {
      lastDocumentID = doc;
   }

   @Override
   public String toString() {
      if (terms.size() == 0) {
         return "No Postings Matched This Query Search :)\n";
      } else if (terms.get(0) instanceof NegativeTerm) {
         return "Term was Not Found in :" + terms.size()+"\n";
      } else {
         String out = terms.get(0).getTerm() + " = \t";
         StringBuilder mutator = new StringBuilder(out);
         for (Terms t : terms) {
            mutator.append(t.toString());
         }
         out = mutator.toString();
         return out + "\n";
      }
   }
}
