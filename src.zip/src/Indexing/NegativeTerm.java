/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Indexing;

/**
 *
 * @author rl07bebb
 */
public class NegativeTerm extends Terms {

   private int docIndex;
   private String docId;

   public NegativeTerm(int di, String n) {
      docIndex = di;
      docId = n;
   }

   public int getIndex() {
      return docIndex;
   }

   public String getId() {
      return docId;
   }
   
   @Override public String toString(){
      return docId;
   }
}
