/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Indexing;

import Analyzing.Document;
import Analyzing.DocumentAnalyzer;
import java.io.Serializable;

/**
 * This Class is used to get the index of the PostingsList that a given term.
 *
 * @author rl07bebb
 */
public class PostingIndex implements Serializable {

   private final String term;
   private int numDocsContainingTerm;
   private final int locationInPL;

   /**
    * This Constructor works to create a new Index for a new Postings for a new
    * term to be added in the PostinsList. 
    * @param t
    * @param d
    * @param postIndexLoc
    * @param l
    * @param postingsList 
    */
   public PostingIndex(String t, Document d, int postIndexLoc, int l, PostingsList postingsList) {
      term = t;
      numDocsContainingTerm = 1;
      locationInPL = postIndexLoc;
      Postings posting = new Postings(t, d, l);
      postingsList.postingsList.add(posting);
   }

   /**
    * This method holds the number of Documents that has a given term.
    */
   public void foundInNewDoc() {
      numDocsContainingTerm++;
   }

   /*
   
            Getters
   
   */
   public int getDocContainTerm() {
      return numDocsContainingTerm;
   }

   public int getLocationInPL() {
      return locationInPL;
   }

   public String getTerm() {
      return term;
   }
}
