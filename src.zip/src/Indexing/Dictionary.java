package Indexing;

import Analyzing.Document;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * This class has creates the data structure used to hold the terms which has
 * the reference to the content in the file.
 *
 * @author rl07bebb
 */
public class Dictionary implements Serializable {

   private HashMap<String, PostingIndex> dictionary;
   private HashMap<String, DocIndex> docMap;

   /**
    * This constructor is only used to create a instantiate version of the
    * dictionary for lesser dictionaries.
    *
    * @param p
    */
   public Dictionary() {
      dictionary = new HashMap<>();
      docMap=new HashMap<>();
   }

   /**
    * This method returns the hashmap of the Dictionary Class.
    *
    * @return
    */
   public HashMap<String, PostingIndex> getHash() {
      return dictionary;
   }
   
   public HashMap<String, DocIndex> getDash() {
      return docMap;
   }

   /**
    * This method is responsible for getting the Postings ArrayList of Terms
    *
    * @param s
    * @return
    */
   public PostingIndex getPostingIndex(String s) {
      PostingIndex pI = dictionary.get(s);
      if (pI == null) {
         return null;
      }
      return pI;
   }
   
   public int getIndex(String s) {
      PostingIndex pI = dictionary.get(s);
      if (pI == null) {
         return -1;
      }
      return pI.getIndex();
   }
   
   public DocIndex getDocIndex(String s) {
      DocIndex dI = docMap.get(s);
      if (dI == null) {
         return null;
      }
      return dI;
   }
   
   public int getDocValue(String s) {
      DocIndex dI = docMap.get(s);
      if (dI == null) {
         return -1;
      }
      return dI.getIndex();
   }
   
   /**
    * This method is used to check if a term is new and if so it will create and
    * add the the new term or it will update that term with the new occurrence.
    * This version of the method is for instantiated Dictionaries.
    *
    * @param s the String of term to be checked
    * @return 
    */
   public boolean isNewTerm(String s) {
      return !dictionary.containsKey(s);
   }
   
   public void putPosting(String s, PostingIndex postingIndex){
      dictionary.put(s, postingIndex);
   }
   
   public void putDoc(String s, DocIndex docIndex){
      docMap.put(s, docIndex);
   }

   /**
    * This Method is simply to get the size of the hashmap dictionary.
    *
    * @return
    */
   public int size() {
      return dictionary.size();
   }
   
   public int sizeDocList() {
      return docMap.size();
   }
}
