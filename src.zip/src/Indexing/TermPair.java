/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Indexing;

/**
 *
 * @author rl07bebb
 */
public class TermPair extends Terms {

   private Terms term1;
   private Terms term2;

   public TermPair(Terms t1, Terms t2) {
      term1 = t1;
      term2 = t2;
   }
   
   @Override
   public String getTerm(){
      return term1.getTerm()+" and "+term2.getTerm();
   }

   @Override
   public String toString() {
      return "<Doc = " + term1.getDocID() + " [ "+term1.getTerm()+" Freq = " + 
              term1.getFreq() + " | First Occurence = " + term1.getFOccurence()+
              " ] [ "+term2.getTerm()+" Freq = " + term2.getFreq()+ 
              " | First Occurence = " + term2.getFOccurence()+" ]\n";
   }
}
