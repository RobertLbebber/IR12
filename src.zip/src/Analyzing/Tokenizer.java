/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Analyzing;

import Indexing.Dictionary;
import Indexing.DocIndex;
import Indexing.PostingIndex;
import Indexing.Postings;
import Indexing.PostingsList;
import Indexing.Terms;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Pattern;

/**
 * This class is used to remove stop words and remove punctuation of words.
 *
 * @author rl07bebb
 */
public class Tokenizer {

   private ArrayList<String> stopWords;
   private Pattern pattern = Pattern.compile("[\\W\\d]");
   private PostingsList postingsList;
   private DocumentList documentList;
   private int indexLoc;
   private int docLoc;

   public Tokenizer(PostingsList p, DocumentList d) {
      postingsList = p;
      documentList = d;
   }

   /**
    * This method is responsible for creating a list of words to be ignored
    *
    * @param stopList
    * @param p
    */
   public Tokenizer(File stopList, PostingsList p) {
      postingsList = p;
      documentList = new DocumentList();
      stopWords = new ArrayList<>();
      try (Scanner scanner = new Scanner(stopList)) {
         while (scanner.hasNext()) {
            stopWords.add(pattern.matcher(scanner.next()).replaceAll(""));
         }
      } catch (IOException e) {
         System.err.println("Tokenizer.Constructor:Error");
         e.printStackTrace();
      }
   }

   public PostingsList getPostList() {
      return postingsList;
   }

   public DocumentList getDocList() {
      return documentList;
   }

   public boolean containsInStopList(String s) {
      return stopWords.contains(s);
   }

   /**
    * This method reads from the doc file and accounts for ever term and calls
    * the proceeding methods for the inclusion of the terms to the dictionary.
    *
    * @param doc the document to be read from
    * @param dictionary the dictionary to be used. static Dictionary by default
    * @param read
    * @return
    */
   public void readFile(Document doc, Dictionary dictionary, File read) {
      int wordLoc = 0;
      documentList.add(doc);
      try (Scanner scanner = new Scanner(read)) {
         while (scanner.hasNext()) {
            String word = scanner.next().toLowerCase();
            word = pattern.matcher(word).replaceAll("");
            if (word.length() > 0) {
               wordLoc++;
               if (stopWords.contains(word)) {
               } else {
                  alterDictionary(word, wordLoc, doc, dictionary);
               }
            }
         }
      } catch (IOException e) {
         System.err.println("Tokenizer.readFile():Error");
         e.printStackTrace();
      }
      return;
   }

   private void alterDictionary(String word, int wordLoc, Document doc,
           Dictionary dictionary) {

      if (dictionary.isNewTerm(word)) {
         PostingIndex postIn = new PostingIndex(word, doc.getDocID(),
                 indexLoc, wordLoc, postingsList);
         dictionary.putPosting(word, postIn);
         doc.add(postIn.getIndex());
         indexLoc++;
      } else {
         PostingIndex postingIndex = dictionary.getPostingIndex(word);
         if (postingIndex == null) {
            return;
         }
         int postIn=postingIndex.getIndex();
         doc.add(postIn);
         Postings post = postingsList.get(postIn);
         if (post.isNewDocument(doc)) {
            postingIndex.foundInNewDoc();
            String docId = doc.getDocID();
            dictionary.putDoc(docId, new DocIndex(docId, docLoc));
            docLoc++;
            post.terms.add(new Terms(word, docId, wordLoc));
            post.setLastDoc(doc.getDocID());
            return;
         }
         Terms term = post.terms.get(post.last());
         term.incrementFreq();
      }
   }

   /**
    * This method is suppose to preform the same operations as readFile, but
    * includes a local dictionary and is pertaining to a query. See readFile.
    *
    * @param doc
    * @param dictionary
    */
   public void readQuery(String input, Dictionary dictionary) {
      int wordLoc = 0;
      try (Scanner scanner = new Scanner(input)) {
         while (scanner.hasNext()) {
            String word = scanner.next().toLowerCase();
            word = pattern.matcher(word).replaceAll("");
            if (word.length() > 0) {
               wordLoc++;
               if (stopWords.contains(word)) {
               } else {
                  alterDictionary(word, wordLoc, new Document("User Query"), dictionary);
               }
            }
         }
      }
   }

   /**
    * This method returns all elements in the stoplist to string.
    *
    * @return
    */
   public String toStopList() {
      String all = "";
      StringBuilder mutator = new StringBuilder(all);
      if (stopWords == null) {
         return "stopWords = null";
      }
      for (String s : stopWords) {
         mutator.append(s);
      }
      all = mutator.toString();
      return all;
   }
}
