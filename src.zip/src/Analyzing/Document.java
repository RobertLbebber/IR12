/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Analyzing;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * This Class is basically a simplified version of the File class that it holds.
 *
 * @author rl07bebb
 */
public class Document implements Serializable {

   private String docId;
   private ArrayList<Integer> termsLoc;

   /**
    * This Constructor is used to build a Document.
    *
    * @param s
    */
   public Document(String s) {
      termsLoc=new ArrayList<> (200);
      docId = s;
   }

   /**
    * This method gets the DocId
    *
    * @return
    */
   public String getDocID() {
      return docId;
   }

   public void add(Integer s) {
      termsLoc.add(s);
   }

   public void remove(String s) {
      termsLoc.remove(s);
   }

   public int indexOf(int i) {
      return termsLoc.indexOf(i);
   }

   public int size() {
      return termsLoc.size();
   }
   
   public boolean contains(Integer s){
      return termsLoc.contains(s);
   }

   @Override
   public String toString() {
      StringBuilder mutator = new StringBuilder();
      String s;
      for (Integer t : termsLoc) {
         mutator.append(" Term Location in PostingIndex = "+t+" ");
      }
      s = mutator.toString();
      return s;
   }
}
