/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Analyzing;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author rl07bebb
 */
public class DocumentList implements Serializable{
   private ArrayList<Document> documentList=new ArrayList<>();
     
   public ArrayList<Document> getAll(){
      return documentList;
   }
   
   public void add(Document d){
      documentList.add(d);
   }
   
   public boolean contains(Document d){
      return documentList.contains(d);
   }
   
   public Document get(int i){
      return documentList.get(i);
   }
   
   public String getId(int d){
      return documentList.get(d).getDocID();
   }
   
   public int size(){
      return documentList.size();
   }
}
