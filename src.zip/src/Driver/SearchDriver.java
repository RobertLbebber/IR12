package Driver;

import Analyzing.Document;
import Indexing.Dictionary;
import Indexing.Postings;
import Indexing.PostingsList;
import Searching.Search;

import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;

/**
 * Created by robert on 2/27/17.
 */
public class SearchDriver {

   public static void main(String args[]) {
      File search = null;
      File results = null;
      File postingFile = null;
      File stopList = null;
      PostingsList searchPost = new PostingsList();
      try {
         search = new File("src/Searching/Search.txt");
         results = new File("src/Searching/Results.txt");
         postingFile = new File("src/Indexing/PostingFile.txt");
         stopList = new File("src/Analyzing/stoplist.txt");
      } catch (Exception e) {
      }

      if (postingFile == null || postingFile.length() == 0) {
         return;
      }
      try {
         ObjectInputStream ois = new ObjectInputStream(new FileInputStream("output.ser"));
         Dictionary fullDictionary = (Dictionary) ois.readObject();
         ObjectInputStream ois2 = new ObjectInputStream(new FileInputStream("postingsList.ser"));
         PostingsList fullPostingsList = (PostingsList) ois2.readObject();
         Search searching = new Search(stopList, fullPostingsList);
         Dictionary dictionary = null;
         String s;
         s = searching.searchFromPosting(search, fullDictionary);
         if (dictionary == null || dictionary.size() == 0) {
         }
         System.out.println(s);
         new PostingsList(new Document(results)).writeList(s);
      } catch (Exception e) {
         e.printStackTrace();
      }
   }
}
