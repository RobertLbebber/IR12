package Driver;

import Analyzing.Document;
import Analyzing.DocumentList;
import Indexing.Dictionary;
import Indexing.Postings;
import Indexing.PostingsList;
import Searching.Search;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Created by robert on 2/27/17.
 */
public class SearchDriver {

   public static Dictionary fullDictionary;
   public static PostingsList fullPostingsList;
   public static DocumentList docList;

   public static void main(String args[]) {
      /*File search = null;*/
      /*File results = null;*/
      /*File postingFile = null;*/
      File stopList = null;
      try {
         /*search = new File("src/Searching/Search.txt");*/
         /*results = new File("src/Searching/Results.txt");*/
         /*postingFile = new File("src/Indexing/PostingFile.txt");*/
         stopList = new File("src/Analyzing/stoplist.txt");
      } catch (Exception e) {
         e.printStackTrace();
      }
      
      /**
      *if (search == null) {
      *   
      *} else if (search.length() == 0) {
      *   System.out.println("The File that you are searching from : \n" + search.getName() + "\ncould not be found or is empty.");
      *   return;
      *}
      **/
      try {
         ObjectInputStream ois = new ObjectInputStream(new FileInputStream("output.tmp"));
         fullDictionary = (Dictionary) ois.readObject();
         ois.close();
         ObjectInputStream ois2 = new ObjectInputStream(new FileInputStream("postingsList.tmp"));
         fullPostingsList = (PostingsList) ois2.readObject();
         ois2.close();
         ObjectInputStream ois3 = new ObjectInputStream(new FileInputStream("doclist.tmp"));
         docList = (DocumentList) ois3.readObject();
         ois3.close();

         Search searching = new Search(stopList);
         String input = searching.userInput();
         /*String result = searching.searchFromDictionary(search, fullDictionary);*/
         String result = searching.searchFromQueryBoolean(input);
         if (result == null || result.length() == 0) {
            System.out.println("There were not matches found for your inquery. Better luck next time :(");
         } else {
            System.out.println(result);
            /*searching.toFile(result, results);*/
         }

      } catch (IOException | ClassNotFoundException e) {
         e.printStackTrace();
      }
   }
}
